import { Injectable } from '@angular/core';
import { catchError, forkJoin, map, of, tap } from 'rxjs';
import { CommunityService } from './community.service';
import { UserService } from './user.service';
import {
  SearchEventResult,
  SearchResults,
  SearchSuggestion
} from '../../shared/models/search.model';
import { CommunityPost } from '../../shared/models/community.model';

@Injectable({ providedIn: 'root' })
export class SearchService {
  private readonly eventCatalog: SearchEventResult[] = [];
  private readonly postCache = new Map<string, CommunityPost[]>();

  constructor(
    private readonly userService: UserService,
    private readonly communityService: CommunityService
  ) {}

  searchAll(query: string, userId: string) {
    const normalizedQuery = query.trim();
    if (!normalizedQuery) {
      return of<SearchResults>({
        query: '',
        users: [],
        posts: [],
        events: []
      });
    }

    return forkJoin({
      users: this.userService.search(normalizedQuery, 24).pipe(catchError(() => of([]))),
      posts: this.getPosts(userId).pipe(
        map((posts) => this.filterPosts(posts, normalizedQuery).slice(0, 24)),
        catchError(() => of([]))
      ),
      events: of(this.filterEvents(normalizedQuery))
    }).pipe(
      map(({ users, posts, events }) => ({
        query: normalizedQuery,
        users,
        posts,
        events
      }))
    );
  }

  getSuggestions(query: string, userId: string) {
    const normalizedQuery = query.trim();
    if (!normalizedQuery) {
      return of<SearchSuggestion[]>([]);
    }

    return forkJoin({
      users: this.userService.search(normalizedQuery, 5).pipe(catchError(() => of([]))),
      posts: this.getPosts(userId).pipe(
        map((posts) => this.filterPosts(posts, normalizedQuery).slice(0, 4)),
        catchError(() => of([]))
      ),
      events: of(this.filterEvents(normalizedQuery).slice(0, 3))
    }).pipe(
      map(({ users, posts, events }) => [
        ...users.map((user) => ({
          id: user.id,
          kind: 'user' as const,
          title: user.displayName,
          subtitle: user.role,
          meta: user.email
        })),
        ...posts.map((post) => ({
          id: post.id,
          kind: 'post' as const,
          title: post.title,
          subtitle: post.authorName,
          meta: post.content
        })),
        ...events.map((event) => ({
          id: event.id,
          kind: 'event' as const,
          title: event.title,
          subtitle: event.location ?? 'Event',
          meta: event.detail
        }))
      ])
    );
  }

  private getPosts(userId: string) {
    const cachedPosts = this.postCache.get(userId);
    if (cachedPosts) {
      return of(cachedPosts);
    }

    return this.communityService.getPosts(userId, 100).pipe(
      tap((posts) => {
        this.postCache.set(userId, posts);
      })
    );
  }

  private filterPosts(posts: CommunityPost[], query: string) {
    const normalizedQuery = query.toLowerCase();
    return posts.filter((post) =>
      post.authorName.toLowerCase().includes(normalizedQuery) ||
      post.title.toLowerCase().includes(normalizedQuery) ||
      post.content.toLowerCase().includes(normalizedQuery)
    );
  }

  private filterEvents(query: string) {
    const normalizedQuery = query.toLowerCase();
    return this.eventCatalog.filter((event) =>
      event.title.toLowerCase().includes(normalizedQuery) ||
      event.detail.toLowerCase().includes(normalizedQuery) ||
      (event.location ?? '').toLowerCase().includes(normalizedQuery)
    );
  }
}
