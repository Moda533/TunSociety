import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, finalize, of, shareReplay, tap, timeout } from 'rxjs';
import { ApiService } from './api.service';
import { AuthResponse, LoginRequest, RegisterRequest } from '../../shared/models/auth.model';
import { User } from '../../shared/models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly requestTimeoutMs = 15000;
  private readonly tokenKey = 'ts_token';
  private readonly userKey = 'ts_user';
  private readonly userSubject = new BehaviorSubject<User | null>(this.readStoredUser());
  private syncRequest$?: Observable<User | null>;
  readonly user$ = this.userSubject.asObservable();

  constructor(private readonly api: ApiService) {}

  register(payload: RegisterRequest) {
    return this.api.post<AuthResponse>('auth/register', payload).pipe(
      timeout(this.requestTimeoutMs),
      tap((response) => this.persistSession(response))
    );
  }

  login(payload: LoginRequest) {
    return this.api.post<AuthResponse>('auth/login', payload).pipe(
      timeout(this.requestTimeoutMs),
      tap((response) => this.persistSession(response))
    );
  }

  oauth(provider: 'google' | 'github') {
    return this.api.post<AuthResponse>(`auth/oauth/${provider}`, {}).pipe(
      timeout(this.requestTimeoutMs)
    );
  }

  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    this.syncRequest$ = undefined;
    this.userSubject.next(null);
  }

  getToken() {
    return localStorage.getItem(this.tokenKey);
  }

  getCurrentUser(): User | null {
    return this.userSubject.value;
  }

  getUserId(): string | null {
    return this.userSubject.value?.id ?? null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken() && !!this.userSubject.value;
  }

  isAdmin(): boolean {
    return this.userSubject.value?.role === 'Admin';
  }

  isModerator(): boolean {
    return this.userSubject.value?.role === 'Moderator';
  }

  isModeratorOrAdmin(): boolean {
    const role = this.userSubject.value?.role;
    return role === 'Moderator' || role === 'Admin';
  }

  updateStoredUser(user: User) {
    this.persistUser(user);
  }

  markCurrentUserFrozen() {
    const user = this.userSubject.value;
    if (!user || user.isFrozen) {
      return;
    }

    this.updateStoredUser({
      ...user,
      isFrozen: true
    });
  }

  private persistSession(response: AuthResponse) {
    localStorage.setItem(this.tokenKey, response.token);
    this.persistUser(response.user);
  }

  syncCurrentUser(force = false): Observable<User | null> {
    const token = this.getToken();
    if (!token) {
      this.clearStoredUser();
      return of(null);
    }

    if (!force && this.syncRequest$) {
      return this.syncRequest$;
    }

    const request$ = this.api.get<User>('users/me').pipe(
      timeout(this.requestTimeoutMs),
      tap((user) => this.persistUser(user)),
      catchError(() => {
        this.clearStoredUser();
        return of(null);
      }),
      finalize(() => {
        this.syncRequest$ = undefined;
      }),
      shareReplay(1)
    );

    this.syncRequest$ = request$;
    return request$;
  }

  private persistUser(user: User) {
    localStorage.setItem(this.userKey, JSON.stringify(user));
    this.userSubject.next(user);
  }

  private clearStoredUser() {
    localStorage.removeItem(this.userKey);
    this.userSubject.next(null);
  }

  private readStoredUser(): User | null {
    const raw = localStorage.getItem(this.userKey);
    if (!raw) {
      return null;
    }

    try {
      const parsed = JSON.parse(raw) as Partial<User>;
      if (parsed.id && parsed.userName && parsed.email && parsed.role) {
        return parsed as User;
      }
    } catch {
      return null;
    }

    return null;
  }
}
