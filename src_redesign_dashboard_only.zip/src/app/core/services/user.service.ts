import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { UpdateUserRequest, User, UserLookup } from '../../shared/models/user.model';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private readonly api: ApiService) {}

  getById(userId: string) {
    return this.api.get<User>(`users/${userId}`);
  }

  getLookupById(userId: string) {
    return this.api.get<UserLookup>(`users/${userId}/lookup`);
  }

  update(userId: string, payload: UpdateUserRequest) {
    return this.api.put<User>(`users/${userId}`, payload);
  }

  search(query: string, take = 20) {
    const encodedQuery = encodeURIComponent(query.trim());
    return this.api.get<UserLookup[]>(`users/search?query=${encodedQuery}&take=${take}`);
  }
}
