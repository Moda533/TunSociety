export interface User {
  id: string;
  userName: string;
  email: string;
  displayName: string;
  role: string;
  isFrozen: boolean;
}

export interface UpdateUserRequest {
  displayName?: string;
  role?: string;
}

export interface UserLookup {
  id: string;
  displayName: string;
  email: string;
  role: string;
}
