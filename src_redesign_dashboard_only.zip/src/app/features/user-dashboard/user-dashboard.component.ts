import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter, map, startWith } from 'rxjs/operators';
import { AuthService } from '../../core/services/auth.service';

type SidebarSection = {
  route: string;
  label: string;
  description: string;
  tips: string[];
  accent: string;
};

@Component({
  selector: 'app-user-dashboard',
  standalone: false,
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss']
})
export class UserDashboardComponent {
  readonly currentUser$;
  readonly sections: SidebarSection[] = [
    {
      route: '/dashboard/feed',
      label: 'Home feed',
      description: 'Publish updates, react to posts, and keep conversations moving.',
      tips: ['Post clearly', 'Keep content policy-safe', 'Use comments to continue the thread'],
      accent: 'Pulse'
    },
    {
      route: '/dashboard/requests',
      label: 'My network',
      description: 'Manage requests, discover members, and grow trusted connections.',
      tips: ['Search by name or email', 'Add a short note only when needed', 'Review pending requests often'],
      accent: 'Connect'
    },
    {
      route: '/dashboard/messenger',
      label: 'Messaging',
      description: 'Open direct conversations and reply from one focused workspace.',
      tips: ['Search members first', 'Use one thread per person', 'Unread conversations stay highlighted'],
      accent: 'Reply'
    },
    {
      route: '/dashboard/notifications',
      label: 'Notifications',
      description: 'Track moderation updates, replies, and new platform activity.',
      tips: ['Keep unread visible', 'Mark items read after acting', 'Check warnings quickly'],
      accent: 'Signal'
    },
    {
      route: '/dashboard/profile',
      label: 'Profile',
      description: 'Control your public identity and keep your account details accurate.',
      tips: ['Use a clear display name', 'Save profile changes carefully', 'Profile names are moderated too'],
      accent: 'Identity'
    }
  ];

  readonly activeSection$;
  readonly showSidebar$;

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router
  ) {
    this.currentUser$ = this.authService.user$;
    this.activeSection$ = this.router.events.pipe(
      filter((event): event is NavigationEnd => event instanceof NavigationEnd),
      startWith(null),
      map(() => this.resolveActiveSection(this.router.url))
    );
    this.showSidebar$ = this.router.events.pipe(
      filter((event): event is NavigationEnd => event instanceof NavigationEnd),
      startWith(null),
      map(() => !this.isWideContentRoute(this.router.url))
    );
  }

  initials(name: string | null | undefined): string {
    const source = name?.trim() || 'Member';
    return source
      .split(/\s+/)
      .filter((part) => part.length > 0)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join('') || 'TS';
  }

  motivationalTitle(section: SidebarSection | null | undefined): string {
    return section ? `${section.label} focus` : 'Workspace focus';
  }

  private resolveActiveSection(url: string): SidebarSection {
    return this.sections.find((section) => url.startsWith(section.route)) ?? this.sections[0];
  }

  private isWideContentRoute(url: string): boolean {
    return url.startsWith('/dashboard/search') || url.startsWith('/dashboard/members/');
  }
}
