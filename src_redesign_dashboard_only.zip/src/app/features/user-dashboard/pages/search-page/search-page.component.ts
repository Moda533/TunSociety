import { ChangeDetectorRef, Component, NgZone, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../../core/services/auth.service';
import { SearchService } from '../../../../core/services/search.service';
import { CommunityPost } from '../../../../shared/models/community.model';
import { SearchResults, SearchScope } from '../../../../shared/models/search.model';
import { UserLookup } from '../../../../shared/models/user.model';

type SearchCategoryOption = {
  key: SearchScope;
  label: string;
};

@Component({
  selector: 'app-search-page',
  standalone: false,
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent implements OnInit, OnDestroy {
  readonly categories: SearchCategoryOption[] = [
    { key: 'all', label: 'All' },
    { key: 'users', label: 'People' },
    { key: 'posts', label: 'Posts' },
    { key: 'events', label: 'Events' }
  ];

  query = '';
  scope: SearchScope = 'all';
  results: SearchResults = {
    query: '',
    users: [],
    posts: [],
    events: []
  };
  isLoading = false;
  errorMessage = '';

  private readonly subscriptions = new Subscription();
  private userId: string | null = null;

  constructor(
    private readonly authService: AuthService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly searchService: SearchService,
    private readonly zone: NgZone,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.authService.user$.subscribe((user) => {
        this.userId = user?.id ?? null;
        this.reloadSearch();
      })
    );

    this.subscriptions.add(
      this.route.queryParamMap.subscribe((params) => {
        this.query = (params.get('query') ?? '').trim();
        this.scope = this.normalizeScope(params.get('scope'));
        this.reloadSearch();
      })
    );

    if (!this.authService.getCurrentUser() && this.authService.getToken()) {
      this.authService.syncCurrentUser().subscribe();
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  get activeUsers(): UserLookup[] {
    return this.scope === 'users' ? this.results.users : this.results.users.slice(0, 6);
  }

  get activePosts(): CommunityPost[] {
    return this.scope === 'posts' ? this.results.posts : this.results.posts.slice(0, 6);
  }

  get showUserSection(): boolean {
    return this.scope === 'all' || this.scope === 'users';
  }

  get showPostSection(): boolean {
    return this.scope === 'all' || this.scope === 'posts';
  }

  get showEventSection(): boolean {
    return this.scope === 'all' || this.scope === 'events';
  }

  get resultCountSummary(): string {
    if (!this.query) {
      return 'Type in the header search to explore members, posts, and events.';
    }

    const totalCount = this.results.users.length + this.results.posts.length + this.results.events.length;
    return `${totalCount} matching results for "${this.query}".`;
  }

  selectScope(scope: SearchScope): void {
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { query: this.query, scope },
      queryParamsHandling: 'merge'
    });
  }

  openMember(user: UserLookup): void {
    void this.router.navigate(['/dashboard/members', user.id], {
      queryParams: { query: this.query }
    });
  }

  openPost(post: CommunityPost): void {
    void this.router.navigate(['/dashboard/feed'], {
      queryParams: { post: post.id }
    });
  }

  trackByUserId(_: number, user: UserLookup): string {
    return user.id;
  }

  trackByPostId(_: number, post: CommunityPost): string {
    return post.id;
  }

  private reloadSearch(): void {
    const userId = this.userId;
    if (!userId || !this.query) {
      this.updateView(() => {
        if (!this.query) {
          this.results = {
            query: '',
            users: [],
            posts: [],
            events: []
          };
        }
        this.isLoading = false;
      });
      return;
    }

    this.updateView(() => {
      this.isLoading = true;
      this.errorMessage = '';
    });

    this.searchService.searchAll(this.query, userId).subscribe({
      next: (results) => {
        this.updateView(() => {
          this.results = results;
          this.isLoading = false;
        });
      },
      error: () => {
        this.updateView(() => {
          this.errorMessage = 'Unable to load search results right now.';
          this.isLoading = false;
        });
      }
    });
  }

  private normalizeScope(scope: string | null): SearchScope {
    return scope === 'users' || scope === 'posts' || scope === 'events' ? scope : 'all';
  }

  private updateView(action: () => void): void {
    this.zone.run(() => {
      action();
      this.changeDetectorRef.detectChanges();
    });
  }
}
