import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Subscription, interval } from 'rxjs';
import { AuthService } from '../../../../core/services/auth.service';
import { CommunityService } from '../../../../core/services/community.service';
import { UserService } from '../../../../core/services/user.service';
import { Conversation, DirectMessage } from '../../../../shared/models/community.model';
import { ModerationFeedback } from '../../../../shared/models/moderation.model';
import { UserLookup } from '../../../../shared/models/user.model';

@Component({
  selector: 'app-messenger-page',
  standalone: false,
  templateUrl: './messenger-page.component.html',
  styleUrls: ['./messenger-page.component.scss']
})
export class MessengerPageComponent implements OnInit, OnDestroy, AfterViewInit {
  readonly chatInputControl = new FormControl('', { nonNullable: true });
  readonly discoverControl = new FormControl('', { nonNullable: true });
  @ViewChild('chatLog') chatLog?: ElementRef<HTMLUListElement>;

  conversations: Conversation[] = [];
  searchResults: UserLookup[] = [];
  selectedConversationId = '';
  isLoading = false;
  isSending = false;
  isSearchingUsers = false;
  errorMessage = '';
  searchErrorMessage = '';
  pendingRecipient: UserLookup | null = null;

  private readonly refreshIntervalMs = 8000;
  private readonly subscriptions = new Subscription();
  userId: string | null = null;

  constructor(
    private readonly authService: AuthService,
    private readonly communityService: CommunityService,
    private readonly userService: UserService,
    private readonly zone: NgZone,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.authService.user$.subscribe((user) => {
        const nextUserId = user?.id ?? null;
        const hadUserId = !!this.userId;
        const shouldLoad = !!nextUserId && (!hadUserId || this.userId !== nextUserId || this.conversations.length === 0);

        this.updateView(() => {
          this.userId = nextUserId;
          if (!nextUserId && !this.authService.getToken()) {
            this.errorMessage = 'Please sign in again.';
          }
        });

        if (shouldLoad) {
          this.loadConversations();
        }
      })
    );

    if (!this.authService.getCurrentUser() && this.authService.getToken()) {
      this.authService.syncCurrentUser().subscribe();
    }

    this.subscriptions.add(
      interval(this.refreshIntervalMs).subscribe(() => {
        if (this.canPollSilently()) {
          this.loadConversations(true);
        }
      })
    );
  }

  ngAfterViewInit(): void {
    this.queueScrollToBottom(false);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  selectConversation(conversationId: string): void {
    this.selectedConversationId = conversationId;
    this.queueScrollToBottom(false);
    this.markConversationRead(conversationId);
  }

  sendMessage(): void {
    const userId = this.userId;
    const text = this.chatInputControl.value.trim();
    const recipientId = this.pendingRecipient?.id ?? this.selectedConversation?.partnerUserId;

    if (!userId || !recipientId || !text) {
      return;
    }

    const previousConversations = this.cloneConversations(this.conversations);
    const previousSelectedConversationId = this.selectedConversationId;
    const previousPendingRecipient = this.pendingRecipient;
    const optimisticMessage = this.createOptimisticMessage(userId, recipientId, text);

    this.isSending = true;
    this.chatInputControl.setValue('');
    this.selectedConversationId = recipientId;
    this.errorMessage = '';
    this.applyOptimisticMessage(
      recipientId,
      optimisticMessage,
      this.pendingRecipient?.displayName ?? this.selectedConversation?.partnerName ?? 'Member',
      this.pendingRecipient?.role ?? this.selectedConversation?.partnerRole ?? 'User'
    );
    this.pendingRecipient = null;
    this.queueScrollToBottom(true);

    this.communityService.sendDirectMessage({
      senderUserId: userId,
      recipientUserId: recipientId,
      content: text
    }).subscribe({
      next: ({ data, moderation }) => {
        this.updateView(() => {
          this.applyModerationAccountState(moderation);
          if (!data) {
            this.conversations = previousConversations;
            this.selectedConversationId = previousSelectedConversationId;
            this.pendingRecipient = previousPendingRecipient;
            this.chatInputControl.setValue(text);
            this.errorMessage = this.buildModerationMessage('Message not sent.', moderation);
            this.isSending = false;
            return;
          }

          this.replaceOptimisticMessage(recipientId, optimisticMessage.id, data);
          this.errorMessage = '';
          this.isSending = false;
          this.queueScrollToBottom(true);
        });
      },
      error: (error: unknown) => {
        this.updateView(() => {
          this.conversations = previousConversations;
          this.selectedConversationId = previousSelectedConversationId;
          this.pendingRecipient = previousPendingRecipient;
          this.chatInputControl.setValue(text);
          this.errorMessage = this.extractErrorMessage(error, 'Unable to send message right now.');
          this.isSending = false;
        });
      }
    });
  }

  get selectedConversation(): Conversation | null {
    return this.conversations.find((item) => item.partnerUserId === this.selectedConversationId) ?? null;
  }

  get activePartnerName(): string {
    return this.selectedConversation?.partnerName ?? this.pendingRecipient?.displayName ?? 'Select a conversation';
  }

  get activePartnerMeta(): string {
    return this.selectedConversation?.lastMessageAtUtc
      ? this.selectedConversation.lastMessageAtUtc
      : this.pendingRecipient?.role ?? 'New conversation';
  }

  get activeMessages() {
    return this.selectedConversation?.messages ?? [];
  }

  get unreadConversationCount(): number {
    return this.conversations.filter((conversation) => conversation.unreadCount > 0).length;
  }

  get activeConversationUnread(): number {
    return this.selectedConversation?.unreadCount ?? 0;
  }

  trackByConversationId(_: number, conversation: Conversation): string {
    return conversation.partnerUserId;
  }

  trackByMessageId(_: number, message: DirectMessage): string {
    return message.id;
  }

  trackByUserId(_: number, user: UserLookup): string {
    return user.id;
  }

  searchUsers(): void {
    const query = this.discoverControl.value.trim();
    if (!query) {
      this.searchResults = [];
      this.searchErrorMessage = '';
      return;
    }

    this.isSearchingUsers = true;
    this.searchErrorMessage = '';

    this.userService.search(query, 10).subscribe({
      next: (users) => {
        this.updateView(() => {
          this.searchResults = users;
          this.isSearchingUsers = false;
        });
      },
      error: () => {
        this.updateView(() => {
          this.searchErrorMessage = 'Unable to search users right now.';
          this.isSearchingUsers = false;
        });
      }
    });
  }

  startConversation(user: UserLookup): void {
    const existingConversation = this.conversations.find((conversation) => conversation.partnerUserId === user.id);
    this.pendingRecipient = existingConversation ? null : user;
    this.selectedConversationId = user.id;
    this.searchResults = [];
    this.searchErrorMessage = '';
    this.discoverControl.setValue('');
    this.queueScrollToBottom(false);
  }

  private loadConversations(silent = false, preferredPartnerId = ''): void {
    const userId = this.userId;
    if (!userId) {
      return;
    }

    if (!silent) {
      this.isLoading = true;
    }

    this.communityService.getConversations(userId, 120).subscribe({
      next: (items) => {
        this.updateView(() => {
          this.conversations = items;

          if (preferredPartnerId && this.conversations.some((item) => item.partnerUserId === preferredPartnerId)) {
            this.selectedConversationId = preferredPartnerId;
          }

          if (!this.selectedConversationId && this.conversations.length > 0) {
            this.selectedConversationId = this.conversations[0].partnerUserId;
          }

          if (this.selectedConversationId && !this.conversations.some((item) => item.partnerUserId === this.selectedConversationId)) {
            this.selectedConversationId = this.conversations[0]?.partnerUserId ?? '';
          }

          this.errorMessage = '';
          this.isLoading = false;
          this.queueScrollToBottom(false);

          if (this.selectedConversationId) {
            this.markConversationRead(this.selectedConversationId);
          }
        });
      },
      error: () => {
        this.updateView(() => {
          this.errorMessage = 'Unable to load conversations.';
          this.isLoading = false;
        });
      }
    });
  }

  private markConversationRead(partnerUserId: string): void {
    const userId = this.userId;
    if (!userId || !partnerUserId) {
      return;
    }

    this.communityService.markConversationRead(userId, partnerUserId).subscribe({
      next: () => {
        this.updateView(() => {
          this.conversations = this.conversations.map((conversation) =>
            conversation.partnerUserId === partnerUserId
              ? { ...conversation, unreadCount: 0, messages: conversation.messages.map((message) => ({
                  ...message,
                  isRead: message.recipientUserId === userId ? true : message.isRead
                })) }
              : conversation
          );
        });
      },
      error: () => {
        // Silent failure to avoid noisy UX.
      }
    });
  }

  private queueScrollToBottom(smooth = true): void {
    setTimeout(() => {
      this.scrollToBottom(smooth);
    }, 0);
  }

  private scrollToBottom(smooth = true): void {
    const log = this.chatLog?.nativeElement;
    if (!log) {
      return;
    }

    log.scrollTo({
      top: log.scrollHeight,
      behavior: smooth ? 'smooth' : 'auto'
    });
  }

  private applyModerationAccountState(moderation: ModerationFeedback): void {
    if (moderation.accountFrozen) {
      this.authService.markCurrentUserFrozen();
    }
  }

  private buildModerationMessage(prefix: string, moderation: ModerationFeedback): string {
    const parts = [prefix];
    if (moderation.reason) {
      parts.push(moderation.reason);
    }

    if (moderation.warningCount > 0) {
      parts.push(`Warning ${moderation.warningCount} of 3.`);
    }

    if (moderation.accountFrozen) {
      parts.push('Your account is now frozen.');
    }

    return parts.join(' ').trim();
  }

  private extractErrorMessage(error: unknown, fallback: string): string {
    if (error && typeof error === 'object' && 'status' in error && (error as { status?: number }).status === 423) {
      this.authService.markCurrentUserFrozen();
    }

    if (error && typeof error === 'object' && 'error' in error) {
      const payload = (error as { error?: unknown }).error;
      if (typeof payload === 'string' && payload.trim().length > 0) {
        return payload;
      }
    }

    return fallback;
  }

  private canPollSilently(): boolean {
    return !document.hidden && !this.isLoading && !this.isSending && !this.isSearchingUsers;
  }

  private createOptimisticMessage(userId: string, recipientId: string, content: string): DirectMessage {
    return {
      id: `temp-${Date.now()}`,
      senderUserId: userId,
      senderName: this.authService.getCurrentUser()?.displayName || this.authService.getCurrentUser()?.userName || 'You',
      recipientUserId: recipientId,
      recipientName: this.pendingRecipient?.displayName ?? this.selectedConversation?.partnerName ?? 'Member',
      content,
      createdAtUtc: new Date().toISOString(),
      isRead: true
    };
  }

  private applyOptimisticMessage(partnerUserId: string, message: DirectMessage, partnerName: string, partnerRole: string): void {
    const existingConversation = this.conversations.find((conversation) => conversation.partnerUserId === partnerUserId);

    if (!existingConversation) {
      this.conversations = [{
        partnerUserId,
        partnerName,
        partnerRole,
        lastMessageAtUtc: message.createdAtUtc,
        isPartnerOnline: false,
        unreadCount: 0,
        messages: [message]
      }, ...this.conversations];
      return;
    }

    this.conversations = [
      {
        ...existingConversation,
        lastMessageAtUtc: message.createdAtUtc,
        unreadCount: 0,
        messages: [...existingConversation.messages, message]
      },
      ...this.conversations.filter((conversation) => conversation.partnerUserId !== partnerUserId)
    ];
  }

  private replaceOptimisticMessage(partnerUserId: string, tempMessageId: string, message: DirectMessage): void {
    this.conversations = this.conversations.map((conversation) =>
      conversation.partnerUserId === partnerUserId
        ? {
            ...conversation,
            lastMessageAtUtc: message.createdAtUtc,
            messages: conversation.messages.map((item) => item.id === tempMessageId ? message : item)
          }
        : conversation
    );
  }

  private cloneConversations(conversations: Conversation[]): Conversation[] {
    return conversations.map((conversation) => ({
      ...conversation,
      messages: conversation.messages.map((message) => ({ ...message }))
    }));
  }

  private updateView(action: () => void): void {
    this.zone.run(() => {
      action();
      this.changeDetectorRef.detectChanges();
    });
  }
}
