import { ChangeDetectorRef, Component, NgZone, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../../../core/services/auth.service';
import { CommunityService } from '../../../../core/services/community.service';
import { UserService } from '../../../../core/services/user.service';
import { CommunityPost } from '../../../../shared/models/community.model';
import { UserLookup } from '../../../../shared/models/user.model';

@Component({
  selector: 'app-member-page',
  standalone: false,
  templateUrl: './member-page.component.html',
  styleUrls: ['./member-page.component.scss']
})
export class MemberPageComponent implements OnInit, OnDestroy {
  member: UserLookup | null = null;
  memberPosts: CommunityPost[] = [];
  isLoading = false;
  errorMessage = '';
  searchQuery = '';

  private readonly subscriptions = new Subscription();
  private userId: string | null = null;
  private memberId = '';

  constructor(
    private readonly authService: AuthService,
    private readonly userService: UserService,
    private readonly communityService: CommunityService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly zone: NgZone,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.authService.user$.subscribe((user) => {
        this.userId = user?.id ?? null;
        this.loadMemberView();
      })
    );

    this.subscriptions.add(
      this.route.paramMap.subscribe((params) => {
        this.memberId = params.get('id') ?? '';
        this.loadMemberView();
      })
    );

    this.subscriptions.add(
      this.route.queryParamMap.subscribe((params) => {
        this.searchQuery = (params.get('query') ?? '').trim();
      })
    );

    if (!this.authService.getCurrentUser() && this.authService.getToken()) {
      this.authService.syncCurrentUser().subscribe();
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  get memberInitial(): string {
    return this.member?.displayName.charAt(0).toUpperCase() ?? 'M';
  }

  openSearchResults(): void {
    void this.router.navigate(['/dashboard/search'], {
      queryParams: {
        query: this.searchQuery || this.member?.displayName || '',
        scope: 'users'
      }
    });
  }

  openFeedPost(post: CommunityPost): void {
    void this.router.navigate(['/dashboard/feed'], {
      queryParams: { post: post.id }
    });
  }

  trackByPostId(_: number, post: CommunityPost): string {
    return post.id;
  }

  private loadMemberView(): void {
    const userId = this.userId;
    if (!userId || !this.memberId) {
      return;
    }

    this.updateView(() => {
      this.isLoading = true;
      this.errorMessage = '';
    });

    this.userService.getLookupById(this.memberId).subscribe({
      next: (member) => {
        this.communityService.getPosts(userId, 100).subscribe({
          next: (posts) => {
            this.updateView(() => {
              this.member = member;
              this.memberPosts = posts.filter((post) => post.userId === this.memberId).slice(0, 8);
              this.isLoading = false;
            });
          },
          error: () => {
            this.updateView(() => {
              this.member = member;
              this.memberPosts = [];
              this.isLoading = false;
            });
          }
        });
      },
      error: () => {
        this.updateView(() => {
          this.member = null;
          this.memberPosts = [];
          this.errorMessage = 'Unable to load this member right now.';
          this.isLoading = false;
        });
      }
    });
  }

  private updateView(action: () => void): void {
    this.zone.run(() => {
      action();
      this.changeDetectorRef.detectChanges();
    });
  }
}
