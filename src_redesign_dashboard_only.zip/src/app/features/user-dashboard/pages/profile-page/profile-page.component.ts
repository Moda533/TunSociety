import { ChangeDetectorRef, Component, NgZone, OnInit, inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';
import { UserService } from '../../../../core/services/user.service';
import { User } from '../../../../shared/models/user.model';

@Component({
  selector: 'app-profile-page',
  standalone: false,
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.scss']
})
export class ProfilePageComponent implements OnInit {
  private readonly fb = inject(FormBuilder);

  currentUser: User | null = null;
  isLoading = false;
  isSaving = false;
  errorMessage = '';
  successMessage = '';

  readonly profileForm = this.fb.nonNullable.group({
    displayName: ['', [Validators.required, Validators.minLength(2)]]
  });

  constructor(
    private readonly authService: AuthService,
    private readonly userService: UserService,
    private readonly zone: NgZone,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe((user) => {
      const nextUserId = user?.id ?? null;
      const shouldLoad = !!nextUserId && (!this.currentUser || this.currentUser.id !== nextUserId);

      this.updateView(() => {
        this.currentUser = user;
      });

      if (shouldLoad) {
        this.loadProfile(nextUserId);
      }
    });

    if (!this.authService.getCurrentUser() && this.authService.getToken()) {
      this.authService.syncCurrentUser().subscribe();
    }
  }

  saveProfile(): void {
    const userId = this.authService.getUserId();
    if (!userId) {
      this.errorMessage = 'Please sign in again.';
      return;
    }

    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }

    this.isSaving = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.userService.update(userId, this.profileForm.getRawValue())
      .subscribe({
        next: (user) => {
          this.updateView(() => {
            this.applyUser(user);
            this.successMessage = 'Profile updated.';
            this.isSaving = false;
          });
        },
        error: (error: unknown) => {
          this.updateView(() => {
            this.errorMessage = this.extractErrorMessage(error, 'Unable to update your profile.');
            this.isSaving = false;
          });
        }
      });
  }

  get memberStatus(): string {
    return this.currentUser?.isFrozen ? 'Frozen' : 'Active';
  }

  get currentUserInitials(): string {
    const source = this.currentUser?.displayName || this.currentUser?.userName || 'Member';
    return source
      .split(/\s+/)
      .filter((part) => part.length > 0)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join('') || 'TS';
  }

  private applyUser(user: User): void {
    this.currentUser = user;
    this.profileForm.patchValue({
      displayName: user.displayName
    });
    this.authService.updateStoredUser(user);
  }

  private loadProfile(userId: string): void {
    this.updateView(() => {
      this.isLoading = true;
      this.errorMessage = '';
    });

    this.userService.getById(userId).subscribe({
      next: (user) => {
        this.updateView(() => {
          this.applyUser(user);
          this.isLoading = false;
        });
      },
      error: () => {
        this.updateView(() => {
          this.errorMessage = 'Unable to load profile right now.';
          this.isLoading = false;
        });
      }
    });
  }

  private extractErrorMessage(error: unknown, fallback: string): string {
    if (error && typeof error === 'object' && 'status' in error && (error as { status?: number }).status === 423) {
      this.authService.markCurrentUserFrozen();
      this.currentUser = this.authService.getCurrentUser();
    }

    if (error && typeof error === 'object' && 'error' in error) {
      const payload = (error as { error?: unknown }).error;
      if (typeof payload === 'string' && payload.trim().length > 0) {
        return payload;
      }
    }

    return fallback;
  }

  private updateView(action: () => void): void {
    this.zone.run(() => {
      action();
      this.changeDetectorRef.detectChanges();
    });
  }
}
