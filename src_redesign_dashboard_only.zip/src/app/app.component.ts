import { Component, HostListener, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { NavigationStart, Router, RouterOutlet } from '@angular/router';
import {
  animate,
  group,
  query,
  style,
  transition,
  trigger
} from '@angular/animations';
import { Subscription, catchError, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, switchMap } from 'rxjs/operators';
import { AuthService } from './core/services/auth.service';
import { HttpFeedbackService } from './core/services/http-feedback.service';
import { SearchService } from './core/services/search.service';
import { SearchSuggestion } from './shared/models/search.model';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [
    trigger('routeAnimations', [
      transition('* <=> *', [
        style({ position: 'relative' }),
        query(':enter, :leave', [
          style({
            position: 'absolute',
            inset: 0,
            width: '100%'
          })
        ], { optional: true }),
        group([
          query(':leave', [
            animate('260ms ease', style({ opacity: 0, transform: 'translateY(18px) scale(0.985)' }))
          ], { optional: true }),
          query(':enter', [
            style({ opacity: 0, transform: 'translateY(26px) scale(0.99)' }),
            animate('360ms cubic-bezier(0.2, 0.8, 0.2, 1)', style({ opacity: 1, transform: 'translateY(0) scale(1)' }))
          ], { optional: true })
        ])
      ])
    ])
  ]
})
export class AppComponent implements OnDestroy {
  title = 'TunSociety';
  readonly feedback$;
  readonly searchControl = new FormControl('', { nonNullable: true });
  isMeMenuOpen = false;
  isSearchMenuOpen = false;
  isSearchLoading = false;
  searchSuggestions: SearchSuggestion[] = [];

  private readonly subscriptions = new Subscription();

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly httpFeedback: HttpFeedbackService,
    private readonly searchService: SearchService
  ) {
    this.feedback$ = this.httpFeedback.message$;

    if (this.authService.getToken()) {
      this.authService.syncCurrentUser().subscribe();
    }

    this.subscriptions.add(
      this.router.events
      .pipe(filter((event) => event instanceof NavigationStart))
      .subscribe(() => {
        this.httpFeedback.clear();
        this.isMeMenuOpen = false;
        this.isSearchMenuOpen = false;
      })
    );

    this.subscriptions.add(
      this.searchControl.valueChanges
        .pipe(
          debounceTime(180),
          distinctUntilChanged(),
          switchMap((value) => this.fetchSuggestions(value))
        )
        .subscribe((suggestions) => {
          this.searchSuggestions = suggestions;
          this.isSearchLoading = false;
        })
    );

    this.subscriptions.add(
      this.authService.user$.subscribe((user) => {
        if (!user) {
          this.searchControl.setValue('', { emitEvent: false });
          this.searchSuggestions = [];
          this.isSearchMenuOpen = false;
          this.isSearchLoading = false;
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  isDashboardRoute(): boolean {
    return this.router.url.startsWith('/dashboard');
  }

  isWorkspaceRoute(): boolean {
    return this.router.url.startsWith('/dashboard')
      || this.router.url.startsWith('/admin')
      || this.router.url.startsWith('/moderation');
  }

  isModeratorOrAdmin(): boolean {
    return this.authService.isModeratorOrAdmin();
  }

  isAdmin(): boolean {
    return this.authService.isAdmin();
  }

  currentUserName(): string {
    const user = this.authService.getCurrentUser();
    return user?.displayName || user?.userName || 'Member';
  }

  currentUserStatus(): string {
    return this.authService.getCurrentUser()?.isFrozen ? 'Frozen' : 'Active';
  }

  currentUserRole(): string {
    return this.authService.getCurrentUser()?.role || 'Member';
  }

  currentUserInitials(): string {
    const parts = this.currentUserName()
      .split(/\s+/)
      .filter((part) => part.length > 0)
      .slice(0, 2);

    return parts.map((part) => part[0]?.toUpperCase() ?? '').join('') || 'TS';
  }

  get showSearchDropdown(): boolean {
    if (!this.isLoggedIn() || !this.isSearchMenuOpen) {
      return false;
    }

    const query = this.searchControl.value.trim();
    return query.length > 0 || this.isSearchLoading;
  }

  get showSearchEmptyState(): boolean {
    return this.showSearchDropdown && !this.isSearchLoading && this.searchSuggestions.length === 0;
  }

  toggleMeMenu(event: MouseEvent): void {
    event.stopPropagation();
    this.isSearchMenuOpen = false;
    this.isMeMenuOpen = !this.isMeMenuOpen;
  }

  closeMeMenu(): void {
    this.isMeMenuOpen = false;
  }

  onMeMenuContainerClick(event: MouseEvent): void {
    event.stopPropagation();
  }

  onSearchContainerClick(event: MouseEvent): void {
    event.stopPropagation();
  }

  openSearchMenu(): void {
    if (!this.isLoggedIn()) {
      return;
    }

    this.isMeMenuOpen = false;
    this.isSearchMenuOpen = true;
  }

  submitSearch(): void {
    const query = this.searchControl.value.trim();
    if (!query) {
      this.isSearchMenuOpen = false;
      this.searchSuggestions = [];
      return;
    }

    this.isSearchMenuOpen = false;
    this.searchSuggestions = [];
    void this.router.navigate(['/dashboard/search'], {
      queryParams: {
        query,
        scope: 'all'
      }
    });
  }

  openSearchSuggestion(suggestion: SearchSuggestion): void {
    const query = this.searchControl.value.trim();
    this.isSearchMenuOpen = false;
    this.searchSuggestions = [];

    if (suggestion.kind === 'user') {
      void this.router.navigate(['/dashboard/members', suggestion.id], {
        queryParams: { query }
      });
      return;
    }

    if (suggestion.kind === 'post') {
      void this.router.navigate(['/dashboard/feed'], {
        queryParams: { post: suggestion.id }
      });
      return;
    }

    void this.router.navigate(['/dashboard/search'], {
      queryParams: {
        query,
        scope: 'events'
      }
    });
  }

  logout(): void {
    this.isMeMenuOpen = false;
    this.isSearchMenuOpen = false;
    this.authService.logout();
    this.httpFeedback.clear();
    this.router.navigate(['/auth']);
  }

  dismissFeedback(): void {
    this.httpFeedback.clear();
  }

  prepareRoute(outlet: RouterOutlet): string {
    const path = outlet?.activatedRouteData?.['animation'];
    return path || outlet?.activatedRoute?.routeConfig?.path || this.router.url;
  }

  @HostListener('document:click')
  handleDocumentClick(): void {
    this.isMeMenuOpen = false;
    this.isSearchMenuOpen = false;
  }

  @HostListener('document:keydown.escape')
  handleEscapeKey(): void {
    this.isMeMenuOpen = false;
    this.isSearchMenuOpen = false;
  }

  private fetchSuggestions(query: string) {
    const trimmedQuery = query.trim();
    const userId = this.authService.getUserId();

    if (!this.isLoggedIn() || !trimmedQuery || !userId) {
      this.isSearchLoading = false;
      return of<SearchSuggestion[]>([]);
    }

    this.isSearchLoading = true;
    this.isSearchMenuOpen = true;

    return this.searchService.getSuggestions(trimmedQuery, userId).pipe(
      catchError(() => of<SearchSuggestion[]>([]))
    );
  }
}
